<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SchoolEvent;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SchoolEventController extends Controller
{
    /**
     * List all events with optional filters.
     */
    public function index(Request $request)
    {
        $query = SchoolEvent::with(['creator:id,first_name,last_name', 'class:id,name', 'stream:id,name', 'teachers:id,first_name,last_name']);

        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }
        if ($request->filled('search')) {
            $q = $request->search;
            $query->where(function ($qry) use ($q) {
                $qry->where('title', 'like', "%{$q}%")
                    ->orWhere('description', 'like', "%{$q}%");
            });
        }
        if ($request->filled('class_id')) {
            $query->where('class_id', $request->class_id);
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Optionally mark expired deadlines automatically when fetched
        $events = $query->orderBy('start_date', 'desc')->get();

        $events->transform(function ($event) {
            // If deadline has passed and status is still active, mark as expired (for display)
            if ($event->deadline && $event->deadline < now() && $event->status === 'active') {
                $event->status = 'expired';
                $event->save(); // persist
            }
            return $event;
        });

        return response()->json($events);
    }

    /**
     * Store a new event.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title'           => 'required|string|max:255',
            'description'     => 'nullable|string',
            'type'            => 'required|in:exam,task,holiday,trip,announcement',
            'start_date'      => 'nullable|date',
            'end_date'        => 'nullable|date|after_or_equal:start_date',
            'deadline'        => 'nullable|date',
            'target_parents'  => 'boolean',
            'target_teachers' => 'boolean',
            'target_staff'    => 'boolean',
            'class_id'        => 'nullable|exists:classes,id',
            'stream_id'       => 'nullable|exists:streams,id',
            'teachers'        => 'array',                 // array of user IDs for tasks
            'teachers.*'      => 'exists:users,id',
        ]);

        $validated['created_by'] = $request->user()->id;
        $validated['status'] = 'active';

        $event = SchoolEvent::create($validated);

        // Sync teachers if type is task and teachers array provided
        if ($request->type === 'task' && $request->has('teachers')) {
            $event->teachers()->sync($request->teachers);
        }

        return response()->json($event->load('teachers'), 201);
    }

    /**
     * Update an event.
     */
    public function update(Request $request, $id)
    {
        $event = SchoolEvent::findOrFail($id);

        // Prevent editing if expired
        if ($event->status === 'expired') {
            return response()->json(['message' => 'Cannot edit an expired event.'], 422);
        }

        $validated = $request->validate([
            'title'           => 'sometimes|string|max:255',
            'description'     => 'nullable|string',
            'type'            => 'sometimes|in:exam,task,holiday,trip,announcement',
            'start_date'      => 'nullable|date',
            'end_date'        => 'nullable|date|after_or_equal:start_date',
            'deadline'        => 'nullable|date',
            'target_parents'  => 'boolean',
            'target_teachers' => 'boolean',
            'target_staff'    => 'boolean',
            'class_id'        => 'nullable|exists:classes,id',
            'stream_id'       => 'nullable|exists:streams,id',
            'teachers'        => 'array',
            'teachers.*'      => 'exists:users,id',
        ]);

        $event->update($validated);

        if ($request->has('teachers')) {
            $event->teachers()->sync($request->teachers);
        }

        return response()->json($event->load('teachers'));
    }

    /**
     * Delete an event.
     */
    public function destroy($id)
    {
        $event = SchoolEvent::findOrFail($id);
        $event->delete();
        return response()->json(['message' => 'Event deleted']);
    }

    /**
     * Get list of teachers for assignment.
     */
    public function teachersList()
    {
        $teachers = User::whereHas('roles', function ($q) {
            $q->whereIn('name', ['Teacher', 'Headteacher', 'Deputy Headteacher', 'Head of Department']);
        })->get(['id', 'first_name', 'last_name', 'email']);
        return response()->json($teachers);
    }
}