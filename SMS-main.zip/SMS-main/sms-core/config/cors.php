<?php

return [
    'paths' => ['api/*', 'sanctum/csrf-cookie'],
    'allowed_methods' => ['*'],
    'allowed_origins' => [
        'https://ideal-succotash-4jg7pg75pp4pfxpp-3000.app.github.dev',
    ],
    'allowed_headers' => ['*'],
    'supports_credentials' => true,
];
