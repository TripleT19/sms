import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import ProfilePage from './components/ProfilePage';
import PasswordResetPage from './components/PasswordResetPage';
import UserManagementPage from './components/UserManagementPage';
import AcademicManagementPage from './components/AcademicManagementPage';
import StudentEnrollmentPage from './components/StudentEnrollmentPage';
import AttendancePage from './components/AttendancePage';
import EventsPage from './components/EventsPage';
import GradesPage from './components/GradesPage';
import FinancePage from './components/FinancePage';
import SchoolInfoPage from './components/SchoolInfoPage';   // ← new import

// Placeholder pages for sidebar links (some are replaced above)
const Home = () => (
  <div>
    <h2 className="text-2xl font-semibold mb-4">Dashboard Overview</h2>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-white p-6 rounded-xl shadow">Total Students: 250</div>
      <div className="bg-white p-6 rounded-xl shadow">Total Teachers: 35</div>
      <div className="bg-white p-6 rounded-xl shadow">Active Courses: 12</div>
    </div>
  </div>
);
const Students = () => <div><h2 className="text-2xl font-semibold">Students</h2></div>;
const Teachers = () => <div><h2 className="text-2xl font-semibold">Teachers</h2></div>;
const Courses = () => <div><h2 className="text-2xl font-semibold">Courses</h2></div>;

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/password-reset" element={<PasswordResetPage />} />
        <Route path="/dashboard" element={<Dashboard />}>
          <Route index element={<Home />} />
          <Route path="students" element={<Students />} />
          <Route path="teachers" element={<Teachers />} />
          <Route path="courses" element={<Courses />} />
          <Route path="academic" element={<AcademicManagementPage />} />
          <Route path="enrollment" element={<StudentEnrollmentPage />} />
          <Route path="attendance" element={<AttendancePage />} />
          <Route path="grades" element={<GradesPage />} />
          <Route path="events" element={<EventsPage />} />
          <Route path="finance" element={<FinancePage />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="users" element={<UserManagementPage />} />
          <Route path="settings" element={<SchoolInfoPage />} />   {/* ← now uses the real page */}
        </Route>
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;