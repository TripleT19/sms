import React, { useEffect, useState } from 'react';
import { useNavigate, NavLink, Outlet } from 'react-router-dom';
import {
  FaTachometerAlt,
  FaUserGraduate,
  FaChalkboardTeacher,
  FaBook,
  FaUser,
  FaUsers,
  FaSchool,
  FaCog,
  FaSignOutAlt,
  FaBars,
  FaTimes,
  FaGraduationCap,
  FaClipboardCheck,
  FaCalendarAlt,
  FaStar,
  FaMoneyBillWave,
} from 'react-icons/fa';

const API_BASE = 'https://ideal-succotash-4jg7pg75pp4pfxpp-8000.app.github.dev';

const Dashboard = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('auth_token');
    if (!token) {
      navigate('/login');
      return;
    }

    const fetchUser = async () => {
      try {
        const response = await fetch(`${API_BASE}/api/user`, {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
            Accept: 'application/json',
          },
        });

        if (response.status === 401) {
          localStorage.removeItem('auth_token');
          navigate('/login');
          return;
        }

        if (!response.ok) throw new Error('Failed to fetch user');

        const userData = await response.json();
        setUser(userData);
      } catch (error) {
        console.error(error);
        localStorage.removeItem('auth_token');
        navigate('/login');
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [navigate]);

  const handleLogout = async () => {
    const token = localStorage.getItem('auth_token');
    try {
      await fetch(`${API_BASE}/api/logout`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
    } catch (error) {
      console.error('Logout error:', error);
    }
    localStorage.removeItem('auth_token');
    navigate('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-blue-50">
        <p className="text-gray-600 text-lg">Loading dashboard...</p>
      </div>
    );
  }

  const profilePicUrl = user?.profile_pic
    ? `${API_BASE}/storage/${user.profile_pic}`
    : null;

  return (
    <div className="min-h-screen bg-blue-50">
      {/* Fixed Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full bg-blue-950 text-white flex flex-col transition-all duration-300 ease-in-out z-40 ${
          sidebarOpen ? 'w-64' : 'w-20'
        }`}
      >
        <div className="flex items-center justify-between px-4 py-6 border-b border-blue-800">
          {sidebarOpen && (
            <div className="flex items-center gap-2">
              <FaGraduationCap className="text-2xl text-blue-300" />
              <span className="text-xl font-bold">EduManage</span>
            </div>
          )}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-blue-300 hover:text-white transition"
          >
            {sidebarOpen ? <FaTimes /> : <FaBars />}
          </button>
        </div>

        <nav className="flex-1 py-4 overflow-y-auto">
          <NavLink to="/dashboard" end className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaTachometerAlt className="text-lg" />
            {sidebarOpen && <span>Dashboard</span>}
          </NavLink>
          <NavLink to="/dashboard/students" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaUserGraduate className="text-lg" />
            {sidebarOpen && <span>Students</span>}
          </NavLink>
          <NavLink to="/dashboard/teachers" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaChalkboardTeacher className="text-lg" />
            {sidebarOpen && <span>Teachers</span>}
          </NavLink>
          <NavLink to="/dashboard/courses" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaBook className="text-lg" />
            {sidebarOpen && <span>Courses</span>}
          </NavLink>
          <NavLink to="/dashboard/academic" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaSchool className="text-lg" />
            {sidebarOpen && <span>Academic</span>}
          </NavLink>
          <NavLink to="/dashboard/enrollment" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaUserGraduate className="text-lg" />
            {sidebarOpen && <span>Enrollment</span>}
          </NavLink>
          <NavLink to="/dashboard/attendance" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaClipboardCheck className="text-lg" />
            {sidebarOpen && <span>Attendance</span>}
          </NavLink>
          <NavLink to="/dashboard/grades" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaStar className="text-lg" />
            {sidebarOpen && <span>Grades</span>}
          </NavLink>
          <NavLink to="/dashboard/events" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaCalendarAlt className="text-lg" />
            {sidebarOpen && <span>Events</span>}
          </NavLink>
          <NavLink to="/dashboard/finance" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaMoneyBillWave className="text-lg" />
            {sidebarOpen && <span>Finance</span>}
          </NavLink>
          <NavLink to="/dashboard/profile" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaUser className="text-lg" />
            {sidebarOpen && <span>Profile</span>}
          </NavLink>
          <NavLink to="/dashboard/users" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaUsers className="text-lg" />
            {sidebarOpen && <span>Users</span>}
          </NavLink>
          <NavLink to="/dashboard/settings" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition ${isActive ? 'bg-blue-800 text-white' : 'text-blue-200 hover:bg-blue-800 hover:text-white'}`}>
            <FaCog className="text-lg" />
            {sidebarOpen && <span>Settings</span>}
          </NavLink>
        </nav>

        <div className="p-4 border-t border-blue-800">
          <button onClick={handleLogout} className="flex items-center gap-3 w-full px-4 py-2 text-blue-200 hover:bg-blue-800 hover:text-white rounded-lg transition">
            <FaSignOutAlt />
            {sidebarOpen && <span>Logout</span>}
          </button>
        </div>
      </aside>

      <div className={`flex flex-col min-h-screen transition-all duration-300 ease-in-out ${sidebarOpen ? 'ml-64' : 'ml-20'}`}>
        <header className="bg-white shadow-sm px-6 py-3 flex justify-between items-center sticky top-0 z-30">
          <h1 className="text-2xl font-bold text-blue-900">Dashboard</h1>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <img
                src={profilePicUrl || 'https://via.placeholder.com/40?text=U'}
                alt="User"
                className="w-10 h-10 rounded-full object-cover border-2 border-blue-600"
              />
              <span className="text-gray-700 font-medium hidden sm:block">
                {user?.first_name || user?.name || 'User'}
              </span>
            </div>
            <button onClick={handleLogout} className="md:hidden text-blue-600 hover:text-blue-800 transition" title="Logout">
              <FaSignOutAlt />
            </button>
          </div>
        </header>

        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Dashboard;